set argv0 [lindex $argv 0]
set argv [lrange $argv 1 end]
expr {srand(20261117)}
source $argv0
